chrome.alarms.onAlarm.addListener(function(alarm){
	alert("Time to take a break!");
});